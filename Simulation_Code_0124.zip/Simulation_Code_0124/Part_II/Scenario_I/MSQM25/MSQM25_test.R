rm(list=ls())
library("quantreg")
library("boot")
library("nleqslv")

data.gen=function(n=5000,type=1) {
  #n=100000;type=2
  psi=ifelse(type==1,1,1.5)
  if (type==1) {
    pi_intercept = c(-1,-1.25,-1.25)
  } else {
    pi_intercept = c(-1.5,-1.9,-1.9)
  }
  # data generation
  X1=cbind(rnorm(n,mean=0,sd=1),rnorm(n,mean=0,sd=1))
  colnames(X1)=c("X11","X12")
  A0=rep(0,n)
  pi1=1/(1+exp(-( pi_intercept[1] -psi*A0+psi*X1[,1]+2*psi*(X1[,2]>0))))
  A1= as.numeric( runif(n) < pi1 )
  U2= A1
  X2=cbind(rnorm(n,mean=0,sd=1)+U2,rnorm(n,mean=0,sd=1)+2*U2)
  colnames(X2)=c("X21","X22")
  pi2=1/(1+exp(-( pi_intercept[2]-1.5*psi*A1+psi*X2[,1]+2*psi*(X2[,2]>0))))
  A2= as.numeric( runif(n) < pi2 )
  U3=A2
  X3=cbind(rnorm(n,mean=0,sd=1)+U3,rnorm(n,mean=0,sd=1)+2*U3)
  colnames(X3)=c("X31","X32")
  pi3=1/(1+exp(-( pi_intercept[3]-1.5*psi*A2+psi*X3[,1]+2*psi*(X3[,2]>0))))
  A3= as.numeric( runif(n) < pi3 )
  sd.e=2+2*A3
  epsilonY=rnorm(n,sd=sd.e)
  deltaX1=2*X1[,1]+2*X1[,2]
  deltaX2=2*X2[,1]+2*X2[,2]
  deltaX3=2*X3[,1]+2*X3[,2]
  Y=10-10*(A1+A2+A3)+deltaX1+deltaX2+deltaX3+epsilonY
  mydata=as.data.frame(cbind(X1,X2,X3,A1,A2,A3,Y,pi1,pi2,pi3))
  mydata
}

naive.f=function(data,q,MSQM.formula) {
  mod=rq(formula=MSQM.formula,tau=q,data=data,method="fn")
  mod$coef
}

IPW.f=function(data,q,PS.formula,S.formula,MSQM.formula,Outcome.name,start.value,tau_n) {
  n.steps=length(PS.formula)
  n=dim(data)[1]
  S.mat=IPW.mat = matrix(NA,ncol=n.steps,nrow=n)
  for (j in (1:n.steps)) {
    PS.model = glm(PS.formula[[j]],family=binomial(link="logit"),data=data)
    IPW.mat[,j]=(fitted(PS.model)^(PS.model$y))*((1-fitted(PS.model))^(1-PS.model$y))
    S.model = glm(S.formula[[j]],family=binomial(link="logit"),data=data)
    S.mat[,j]=(fitted(S.model)^(S.model$y))*((1-fitted(S.model))^(1-S.model$y))
  }
  sw = apply(S.mat,1,prod)/apply(IPW.mat,1,prod)
  Xmat = model.matrix(MSQM.formula,data=data)
  n.theta=dim(Xmat)[2]
  est.eq=function(theta) {
    expit=function(x,m,gamma=tau_n) {plogis(m-x,scale=gamma)}
    y=as.numeric(Xmat %*% theta)
    Pval=expit(x=data[,Outcome.name],m=y)
    out=rep(NA,n.theta)
    for (m in (1:n.theta)) {
      out[m] = sum(Xmat[,m]*sw*(Pval-q))
    }
    out
  }
  theta.est=nleqslv::nleqslv(x=start.value,fn=est.eq)$x
  theta.est
}

ICR.f=function(data,q,
               Outcome.formula,
               Var.formula,
               MSQM.formula,
               A.names,Outcome.name,start.value) {
  n.steps=length(A.names)
  n=dim(data)[1]
  coef.list=sigma2.list=Outcome.m.list=Var.m.list=list()
  Outcome.m.list[[1]] = lm(Outcome.formula[[n.steps]],data=data)
  coef.list[[1]]=coef(Outcome.m.list[[1]]);
  EY=predict(Outcome.m.list[[1]],newdata=data)
  data$Sigma2 = (Outcome.m.list[[1]]$residuals)^2
  Var.m.list[[1]] = lm(as.formula(paste("Sigma2 ~",as.character(Var.formula[[n.steps]])[2])),data=data)
  sigma2.list[[1]]=Var.m.list[[1]]$coefficients
  for (j in (1:n.steps)) {
    # generate the extended dataset
    Alist=list()
    for (i in (1:j)) { Alist[[i]]=c(0,1) }
    Alist=expand.grid(Alist);
    Aname.now=A.names[(n.steps-j+1):n.steps]
    colnames(Alist)=Aname.now
    K=2^j
    data_e=data[rep(seq_len(nrow(data)), times = K),]
    for (k in (1:K)) {
      m=(n*(k-1)+1):(n*k)
      for (h in (1:j)) { data_e[m,Aname.now[h]]=Alist[k,h] }
    }
    if (j<n.steps) {
      EY=predict(Outcome.m.list[[j]],newdata=data_e)
      #EY2=sigma2.list[[j]]+EY^2
      data_e[,Outcome.name]=EY
      Outcome.m.list[[j+1]] = lm(Outcome.formula[[n.steps-(j+1)+1]],data=data_e)
      coef.list[[j+1]] = coef(Outcome.m.list[[j+1]])
      my=predict(Outcome.m.list[[j+1]],newdata=data_e)
      data_e$Sigma2 = EY^2 + predict(Var.m.list[[j]],newdata=data_e) - 2*EY*my +my^2
      Var.m.list[[j+1]] = lm(as.formula(paste("Sigma2 ~",as.character(Var.formula[[n.steps-(j+1)+1]])[2])),
                             data=data_e)
      sigma2.list[[j+1]] = Var.m.list[[j+1]]$coefficients
    } else {
      EY=predict(Outcome.m.list[[j]],newdata=data_e)
      Sigma2=predict(Var.m.list[[j]],newdata=data_e)
      Xmat = model.matrix(MSQM.formula,data=data_e)
      n.theta=dim(Xmat)[2]
      est.eq=function(theta) {
        y=as.numeric(Xmat %*% theta)
        Pval=pnorm(y,mean=EY,sd=sqrt(Sigma2))
        out=rep(NA,n.theta)
        for (m in (1:n.theta)) {
          out[m] = sum(Xmat[,m]*(Pval-q))
        }
        out
      }
      theta.est=nleqslv::nleqslv(x=start.value,fn=est.eq)$x
    }
  }
  theta.est
}

DR.f=function(data,q,Outcome.formula,PS.formula,S.formula,Var.formula=Var.formula,MSQM.formula,
              A.names,Outcome.name,start.value,tau_n) {
  n.steps=length(PS.formula)
  n=dim(data)[1]
  # Obtain PS estimates
  PS.m.list=S.m.list=list()
  for (j in (1:n.steps)) {
    PS.m.list[[j]] = glm(PS.formula[[j]],family=binomial(link="logit"),data=data)
    S.m.list[[j]] = glm(S.formula[[j]],family=binomial(link="logit"),data=data)
  }
  # Obtain Outcome model estimates
  coef.list=sigma2.list=Outcome.m.list=Var.m.list=list()
  Outcome.m.list[[1]] = lm(Outcome.formula[[n.steps]],data=data)
  coef.list[[1]]=coef(Outcome.m.list[[1]]);
  EY=predict(Outcome.m.list[[1]],newdata=data)
  data$Sigma2 = (Outcome.m.list[[1]]$residuals)^2
  Var.m.list[[1]] = lm(as.formula(paste("Sigma2 ~",as.character(Var.formula[[n.steps]])[2])),data=data)
  sigma2.list[[1]]=Var.m.list[[1]]$coefficients
  data_e.list=list();data_e.list[[1]]=data
  for (j in (1:(n.steps))) {
    # generate the extended dataset
    Alist=list()
    for (i in (1:j)) { Alist[[i]]=c(0,1) }
    Alist=expand.grid(Alist);
    Aname.now=A.names[(n.steps-j+1):n.steps]
    colnames(Alist)=Aname.now
    K=2^j
    data_e=data[rep(seq_len(nrow(data)), times = K),]
    for (k in (1:K)) {
      m=(n*(k-1)+1):(n*k)
      for (h in (1:j)) { data_e[m,Aname.now[h]]=Alist[k,h] }
    }
    data_e.list[[j+1]]=data_e
    if (j<n.steps) {
      EY=predict(Outcome.m.list[[j]],newdata=data_e)
      #EY2=sigma2.list[[j]]+EY^2
      data_e[,Outcome.name]=EY
      Outcome.m.list[[j+1]] = lm(Outcome.formula[[n.steps-(j+1)+1]],data=data_e)
      coef.list[[j+1]] = coef(Outcome.m.list[[j+1]])
      my=predict(Outcome.m.list[[j+1]],newdata=data_e)
      data_e$Sigma2 = EY^2 + predict(Var.m.list[[j]],newdata=data_e) - 2*EY*my +my^2
      Var.m.list[[j+1]] = lm(as.formula(paste("Sigma2 ~",as.character(Var.formula[[n.steps-(j+1)+1]])[2])),
                             data=data_e)
      sigma2.list[[j+1]]=Var.m.list[[j+1]]$coefficients
    }
  }
  # Calculate the IPW and conditional mean for each step
  sw.list=s.list=list();mean.list.r=mean.list.l=list()
  var.list.r=var.list.l=list()
  for (j in (1:n.steps)) {
    # calculate the IPW
    S.mat=matrix(NA,ncol=n.steps,nrow=dim(data_e.list[[j]]))
    IPW.mat = matrix(NA,ncol=n.steps-j+1,nrow=dim(data_e.list[[j]]))
    for (m in (1:(n.steps-j+1))) {
      ps.now = predict(PS.m.list[[m]],newdata=data_e.list[[j]],type="response")
      IPW.mat[,m]=(ps.now^(data_e.list[[j]][,A.names[m]]))*((1-ps.now)^(1-data_e.list[[j]][,A.names[m]]))
    }
    for (m in (1:(n.steps))) {
      s.now = predict(S.m.list[[m]],newdata=data_e.list[[j]],type="response")
      S.mat[,m]=(s.now^(data_e.list[[j]][,A.names[m]]))*((1-s.now)^(1-data_e.list[[j]][,A.names[m]]))
    }
    s.list[[j]] = apply(S.mat,1,prod)
    sw.list[[j]]=1/apply(IPW.mat,1,prod)
    # calculate the conditional mean and variance
    mean.list.r[[j]]=predict(Outcome.m.list[[j]],newdata=data_e.list[[j]])
    mean.list.l[[j]]=predict(Outcome.m.list[[j]],newdata=data_e.list[[j+1]])
    var.list.r[[j]]=predict(Var.m.list[[j]],newdata=data_e.list[[j]])
    var.list.l[[j]]=predict(Var.m.list[[j]],newdata=data_e.list[[j+1]])
  }
  S.mat=matrix(NA,ncol=n.steps,nrow=dim(data_e.list[[n.steps+1]]))
  for (m in (1:(n.steps))) {
    s.now = predict(S.m.list[[m]],newdata=data_e.list[[n.steps+1]],type="response")
    S.mat[,m]=(s.now^(data_e.list[[n.steps+1]][,A.names[m]]))*((1-s.now)^(1-data_e.list[[n.steps+1]][,A.names[m]]))
  }
  s.list[[n.steps+1]] = apply(S.mat,1,prod)
  # Construct the estimating equation
  Xmat.list=list()
  for (j in (1:(n.steps+1))) {
    Xmat.list[[j]]=model.matrix(MSQM.formula,data=data_e.list[[j]])
  }
  n.theta=dim(Xmat.list[[1]])[2]
  est.eq=function(theta) {
    expit=function(x,m,gamma=tau_n) {plogis(m-x,scale=gamma)}
    y=as.numeric(Xmat.list[[1]] %*% theta)
    Pval=expit(x=data[,Outcome.name],m=y)
    Fval=pnorm(y,mean=mean.list.r[[1]],sd=sqrt(var.list.r[[1]]))
    out=rep(NA,n.theta)
    for (m in (1:n.theta)) {
      out[m] = sum(Xmat.list[[1]][,m]*s.list[[1]]*sw.list[[1]]*(Pval-Fval))
    }
    for (j in (1:(n.steps-1))) {
      y=as.numeric(Xmat.list[[j+1]] %*% theta)
      Pval=pnorm(y,mean=mean.list.l[[j]],sd=sqrt(var.list.l[[j]]))
      Fval=pnorm(y,mean=mean.list.r[[j+1]],sd=sqrt(var.list.r[[j+1]]))
      for (m in (1:n.theta)) {
        out[m] = out[m] + sum(Xmat.list[[j+1]][,m]*s.list[[j+1]]*sw.list[[j+1]]*(Pval-Fval))
      }
    }
    y=as.numeric(Xmat.list[[n.steps+1]] %*% theta)
    Pval=pnorm(y,mean=mean.list.l[[n.steps]],sd=sqrt(var.list.l[[n.steps]]))
    for (m in (1:n.theta)) {
      out[m] = out[m]+sum(Xmat.list[[n.steps+1]][,m]*s.list[[j+2]]*(Pval-q))
    }
    out
  }
  theta.est=nleqslv::nleqslv(x=start.value,fn=est.eq)$x
  theta.est
}




simulation.f=function(samplesize=5000,replication=1000,q=0.5,true.outcome=0,true.ps=1,boot=F) {
  #samplesize=1000;replication=50;q=0.5;boot=F;true.outcome=1;true.ps=0
  n=samplesize
  output1=output2=output3=matrix(NA,ncol=16,nrow=replication)
  colnames(output1)=colnames(output2)=colnames(output3)=c("b0_naive","b1_naive","b2_naive","b3_naive",
                                                          "b0_ipw","b1_ipw","b2_ipw","b3_ipw",
                                                          "b0_ice","b1_ice","b2_ice","b3_ice",
                                                          "b0_dr","b1_dr","b2_dr","b3_dr")
  S.formula=list(as.formula(A1~1),
                 as.formula(A2~A1),
                 as.formula(A3~A1+A2))
  if (true.ps==1) {
    PS.formula=list(as.formula(A1~X11+I(X12>0)),
                    as.formula(A2~A1+X21+I(X22>0)),
                    as.formula(A3~A2+X31+I(X32>0)))
  } else {
    PS.formula=list(as.formula(A1 ~ I(X11*X12>0)   ),
                    as.formula(A2 ~ A1+I(X22*X21>0)),
                    as.formula(A3 ~ A2+I(X32*X31>0)))
  }
  
  if (true.outcome==1) {
    Outcome.formula=list(as.formula(Y~A1+A2+A3+X11+X12),
                         as.formula(Y~A1+A2+A3+X11+X12+X21+X22),
                         as.formula(Y~A1+A2+A3+X11+X12+X21+X22+X31+X32))
    Var.formula = list(as.formula(~A3),
                       as.formula(~A3),
                       as.formula(~A3))
  } else {
    Outcome.formula=list(as.formula(Y~A1+A2+A3+X11+I(X12^2)),
                         as.formula(Y~A1+A2+A3+X11+I(X12^2)+X21+I(X22^2)),
                         as.formula(Y~A1+A2+A3+X11+I(X12^2)+X21+I(X22^2)+X31+I(X32^2)))
    Var.formula = list(as.formula(~A3),
                       as.formula(~A3),
                       as.formula(~A3))
  }
  A.names=c("A1","A2","A3")
  Outcome.name="Y"
  
  MSQM.formula=as.formula(Y~A1+A2+A3)
  for (i in (1:replication)) {
    data=data.gen(n=samplesize)
    start.value=c(7.031783 ,  -1.433264  , -2.335016 ,  -8.295267)
    tryCatch({naive=naive.f(data=data,q=q,MSQM.formula = MSQM.formula)},error=function(e) {naive <<-rep(NA,4)})
    tryCatch({ice=ICR.f(data=data,q=q,Outcome.formula=Outcome.formula,Var.formula=Var.formula,
                        MSQM.formula=MSQM.formula,
                        A.names=A.names,Outcome.name=Outcome.name,start.value=start.value)},
             error=function(e) {ice <<-rep(NA,4)})
    tau_n <<- sd(data[,Outcome.name]-c(model.matrix(MSQM.formula,data=data) %*% ice))*dim(data)[1]^(-0.26) 
    tau_n = sd(data[,Outcome.name]-c(model.matrix(MSQM.formula,data=data) %*% ice))*dim(data)[1]^(-0.26)
    tryCatch({ipw=IPW.f(data=data,q=q,PS.formula=PS.formula,S.formula=S.formula,
                        MSQM.formula=MSQM.formula,Outcome.name = Outcome.name, start.value = start.value,tau_n=tau_n)},
             error=function(e) {ipw <<-rep(NA,4)})
    tryCatch({dr=DR.f(data=data,q=q,PS.formula=PS.formula,S.formula=S.formula,
                      Outcome.formula=Outcome.formula,Var.formula=Var.formula,
                      MSQM.formula=MSQM.formula,
                      A.names=A.names,Outcome.name=Outcome.name,start.value=start.value,tau_n=tau_n)},
             error=function(e) {dr <<-rep(NA,4)})
    output1[i,1:4]=naive;output1[i,5:8]=ipw;output1[i,9:12]=ice;output1[i,13:16]=dr
    parameter.f=function(data,indices) {
      data=data[indices,]
      tryCatch({naive=naive.f(data=data,q=q,MSQM.formula = MSQM.formula)},error=function(e) {naive <<-rnorm(4)})
      tryCatch({ipw=IPW.f(data=data,q=q,PS.formula=PS.formula,S.formula=S.formula,
                          MSQM.formula=MSQM.formula,Outcome.name = Outcome.name, 
                          start.value = start.value,tau_n=tau_n)},
               error=function(e) {ipw <<-rnorm(4)})
      tryCatch({ice=ICR.f(data=data,q=q,Outcome.formula=Outcome.formula,MSQM.formula=MSQM.formula,Var.formula=Var.formula,
                          A.names=A.names,Outcome.name=Outcome.name,start.value=start.value)},
               error=function(e) {ice <<-rnorm(4)})
      tryCatch({dr=DR.f(data=data,q=q,PS.formula=PS.formula,S.formula=S.formula,Var.formula=Var.formula,
                        Outcome.formula=Outcome.formula,MSQM.formula=MSQM.formula,
                        A.names=A.names,Outcome.name=Outcome.name,
                        start.value=start.value,tau_n=tau_n)},
               error=function(e) {dr <<-rnorm(4)})
      out=c(naive,ipw,ice,dr)
    }
    if (boot==T) {
      boot.res <- boot(data=data, statistic=parameter.f, R=50)
      bootci.f=function(res=boot.res) {
        mat=matrix(NA,ncol=16,nrow=2)
        for (j in (1:16)) {
          mat[,j]=boot.ci(res, type="perc",index=j)$percent[4:5]
        }
        mat
      }
      ci=bootci.f(res=boot.res)
    } else {
      ci=matrix(0,ncol=16,nrow=2)
    }
    output2[i,]=ci[1,];output3[i,]=ci[2,]
  }
  # true parameters
  beta.true=c(10+qnorm(q)*sqrt(28),6-10,6-10,(qnorm(q)*sqrt(40)-qnorm(q)*sqrt(28)-10))
  BIAS0=(apply(output1,2,median,na.rm=T)-rep(beta.true,4))/rep(beta.true,4)*100
  SE0 = apply(output1,2,sd,na.rm=T)
  par.mat=matrix(rep(beta.true,4*replication),ncol=16,nrow=replication,byrow=T)
  CR0 = apply(((par.mat-output2)>0)*((par.mat-output3)<0),2,mean,na.rm=T)*100
  res0=round(rbind(BIAS0,SE0,CR0),3)
  BIAS1=matrix(res0[1,],ncol=4,nrow=4,byrow=F)
  SE1=matrix(res0[2,],ncol=4,nrow=4,byrow=F)
  CR1=matrix(res0[3,],ncol=4,nrow=4,byrow=F)
  colnames(BIAS1)=colnames(SE1)=colnames(CR1)=c("Naive","IPW","ICE","DR")
  rownames(BIAS1)=rownames(SE1)=rownames(CR1)=c("beta0","beta1","beta2","beta3")
  list(BIAS=BIAS1,SE=SE1,CR=CR1)
}



aid <- paste(Sys.getenv("PBS_ARRAYID"),
             Sys.getenv("SLURM_ARRAY_TASK_ID"),
             sep = ""
)
aid = as.numeric(aid)[1]

set.seed(aid+2022)

Sys.time()
res1=simulation.f(samplesize=1000,replication=100,q=0.25,true.outcome=1,true.ps=1,boot=T)
print(res1)
Sys.time()

Sys.time()
res2=simulation.f(samplesize=1000,replication=100,q=0.25,true.outcome=0,true.ps=1,boot=T)
print(res2)
Sys.time()

Sys.time()
res3=simulation.f(samplesize=1000,replication=100,q=0.25,true.outcome=1,true.ps=0,boot=T)
print(res3)
Sys.time()

Sys.time()
res4=simulation.f(samplesize=1000,replication=100,q=0.25,true.outcome=0,true.ps=0,boot=T)
print(res4)
Sys.time()


save(res1,res2,res3,res4,file=paste("msqm25",aid,".RData",sep=""))
