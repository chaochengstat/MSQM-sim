source("functions.R")

aid <- paste(Sys.getenv("PBS_ARRAYID"),
             Sys.getenv("SLURM_ARRAY_TASK_ID"),
             sep = ""
)
aid = as.numeric(aid)[1]

set.seed(aid+2022)

Sys.time()
res1=simulation.f(samplesize=2000,replication=100,q=0.25,true.outcome=1,true.ps=1,type=2)
print(res1)
Sys.time()

Sys.time()
res2=simulation.f(samplesize=2000,replication=100,q=0.25,true.outcome=0,true.ps=1,type=2)
print(res2)
Sys.time()

Sys.time()
res3=simulation.f(samplesize=2000,replication=100,q=0.25,true.outcome=1,true.ps=0,type=2)
print(res3)
Sys.time()

Sys.time()
res4=simulation.f(samplesize=2000,replication=100,q=0.25,true.outcome=0,true.ps=0,type=2)
print(res4)
Sys.time()


save(res1,res2,res3,res4,file=paste("msqm25",aid,".RData",sep=""))
