rm(list=ls())
setwd("/Users/chaocheng/Dropbox/Mediation/MSQM/JRSSB revision/Additional Simulation/SA_SIM/SA_Wrong")
list.add = function(a,b) {
  out=a;out[[1]] = rbind(a[[1]],b[[1]]);out[[2]] = rbind(a[[2]],b[[2]]);out[[3]] = rbind(a[[3]],b[[3]])
  out[[4]] = rbind(a[[4]],b[[4]]);out[[5]] = rbind(a[[5]],b[[5]])
  out
}
for (j in (1:10)) {
  load(paste("msqm_s1_",j,".RData",sep=""))
  if (j==1) {
    r1=res1[1:5];r2=res2[1:5];r3=res3[1:5];r4=res4[1:5]
  } else {
    r1=list.add(a=r1,b=res1)
    r2=list.add(a=r2,b=res2)
    r3=list.add(a=r3,b=res3)
    r4=list.add(a=r4,b=res4)
  }
}


data.transfer=function(dat) {
  output1 = dat$output1;output2 = dat$output2;output3 = dat$output3;output4 = dat$output4;
  output5 = dat$output5;
  q=0.5
  beta.true=c(10+qnorm(q)*sqrt(28),6-10,6-10,(qnorm(q)*sqrt(40)-qnorm(q)*sqrt(28)-10))
  BIAS=(apply(output1,2,median,na.rm=T)-rep(beta.true,4))/rep(beta.true,4)*100
  SE = apply(output1,2,sd,na.rm=T)
  par.mat=matrix(rep(beta.true,4*dim(output1)[1]),ncol=16,nrow=dim(output1)[1],byrow=T)
  CR = apply(((par.mat-output2)>0)*((par.mat-output3)<0),2,mean,na.rm=T)*100
  CRb = apply(((par.mat-output4)>0)*((par.mat-output5)<0),2,mean,na.rm=T)*100
  res=round(rbind(BIAS,SE,CR,CRb),3)
  res
}

r1 = data.transfer(r1);r2 = data.transfer(r2);r3 = data.transfer(r3);r4 = data.transfer(r4);

C1=as.data.frame(rbind(
c(paste(round(r1["BIAS",1:4],2)," (",round(r1["SE",1:4],2),")",sep=""),paste(round(r1["CR",1:4],2))),
c(paste(round(r1["BIAS",5:8],2)," (",round(r1["SE",5:8],2),")",sep=""),paste(round(r1["CR",5:8],2))),
c(paste(round(r3["BIAS",5:8],2)," (",round(r3["SE",5:8],2),")",sep=""),paste(round(r3["CR",5:8],2))),
c(paste(round(r1["BIAS",9:12],2)," (",round(r1["SE",9:12],2),")",sep=""),paste(round(r1["CR",9:12],2))),
c(paste(round(r2["BIAS",9:12],2)," (",round(r2["SE",9:12],2),")",sep=""),paste(round(r2["CR",9:12],2))),
c(paste(round(r1["BIAS",13:16],2)," (",round(r1["SE",13:16],2),")",sep=""),paste(round(r1["CR",13:16],2))),
c(paste(round(r2["BIAS",13:16],2)," (",round(r2["SE",13:16],2),")",sep=""),paste(round(r2["CR",13:16],2))),
c(paste(round(r3["BIAS",13:16],2)," (",round(r3["SE",13:16],2),")",sep=""),paste(round(r3["CR",13:16],2))),
c(paste(round(r4["BIAS",13:16],2)," (",round(r4["SE",13:16],2),")",sep=""),paste(round(r4["CR",13:16],2)))
))


table=data.frame(Method=c("Naive","IPW","IPW","ICR","ICR",
                          "DR","DR","DR","DR"),
                 IPW=c("","T","F","","","T","T","F","F"),
                 OR=c("","","","T","F","T","F","T","F"))
mytab=rbind(cbind(table,C1))
mytab
xx=xtable::xtable(mytab[1:9,],
                  include.rownames = FALSE,booktabs = TRUE)
print(xx,include.rownames = FALSE,booktabs = TRUE)

