source("functions.R")

aid <- paste(Sys.getenv("PBS_ARRAYID"),
             Sys.getenv("SLURM_ARRAY_TASK_ID"),
             sep = ""
)
aid = as.numeric(aid)[1]

set.seed(aid+2022)


Sys.time()
res1=simulation.f(samplesize=1000,replication=10,q=0.5,sa_type=2,true.outcome=1,true.ps=1,boot=F)
print(res1)
Sys.time()

Sys.time()
res2=simulation.f(samplesize=1000,replication=10,q=0.5,sa_type=2,true.outcome=0,true.ps=1,boot=F)
print(res2)
Sys.time()

Sys.time()
res3=simulation.f(samplesize=1000,replication=10,q=0.5,sa_type=2,true.outcome=1,true.ps=0,boot=F)
print(res3)
Sys.time()

Sys.time()
res4=simulation.f(samplesize=1000,replication=10,q=0.5,sa_type=2,true.outcome=0,true.ps=0,boot=F)
print(res4)
Sys.time()


save(res1,res2,res3,res4,file=paste("msqm_s2_",aid,".RData",sep=""))
